import React from 'react';
import { Nav } from 'react-bootstrap';
// import './Sidebar.css';

const Sidebar = ({ onClose }) => (
  <div className="sidebar bg-dark text-white p-3">
    <button className="btn-close btn-close-white d-md-none mb-3" onClick={onClose}></button>
    <Nav className="flex-column">
      <Nav.Link href="/parent/dashboard" className="text-white">🏠 Dashboard</Nav.Link>
      <Nav.Link href="/parent/parent-child" className="text-white">👨‍👩‍👧 My Child</Nav.Link>
      <Nav.Link href="/parent/parent-fees" className="text-white">💳 Fees</Nav.Link>
      <Nav.Link href="/parent/parent-receipts" className="text-white">📄 Receipts</Nav.Link>
    </Nav>
  </div>
);

export default Sidebar;
