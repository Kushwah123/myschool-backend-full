// src/pages/parent/ParentDashboard.jsx
import React, { useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import Sidebar from './Sidebar';
import Header from '../../components/Header';
import './ParentDashboard.css';

const Dashboard = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="parent-dashboard d-flex flex-column">
      <Header onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

      <div className="d-flex flex-grow-1">
        {/* Sidebar */}
        <div className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
          <Sidebar onClose={() => setSidebarOpen(false)} />
        </div>

        {/* Main Content */}
        <main className="main-content flex-grow-1 p-3">
          <Container fluid>
            <h4 className="mb-4">👨‍👩‍👧 Welcome to Parent Dashboard</h4>
            <Row className="g-4">
              <Col md={4}>
                <div className="card shadow-sm p-3">
                  <h6>📚 View Child Details</h6>
                </div>
              </Col>
              <Col md={4}>
                <div className="card shadow-sm p-3">
                  <h6>💰 Fee Payment History</h6>
                </div>
              </Col>
              <Col md={4}>
                <div className="card shadow-sm p-3">
                  <h6>📄 Download Receipts</h6>
                </div>
              </Col>
            </Row>
          </Container>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
