import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Form, Button, Card, Container, Row, Col } from "react-bootstrap";
import Select from "react-select";
import { createParent } from "../../redux/slices/parentSlice";
import { fetchStudents } from "../../redux/slices/studentSlice";
import { fetchClasses } from "../../redux/slices/classSlice";
import { toast } from "react-toastify";

const AddParent = () => {
  const dispatch = useDispatch();
  const { students } = useSelector((state) => state.students);
  const { classes } = useSelector((state) => state.class);

  const [form, setForm] = useState({
    fullName: "", mobile: "", email: "", address: "", password: "", studentIds: []
  });
console.log(form.studentIds)
  useEffect(() => {
    dispatch(fetchClasses());
    dispatch(fetchStudents());
  }, [dispatch]);

  // Group students by class for react-select
  const groupedStudentOptions = classes.map((cls) => ({
    label: cls.name,
    options: students
      .filter((s) => s.classId?._id === cls._id)
      .map((s) => ({ label: s.fullName, value: s._id })),
  }));

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleStudentSelect = (selectedOptions) => {
    const selectedIds = selectedOptions.map((opt) => opt.value);
    setForm((prev) => ({ ...prev, studentIds: selectedIds }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.password) return toast.error("Password is required");
    if (form.studentIds.length === 0) return toast.error("Select at least one student");

    try {
      await dispatch(createParent(form)).unwrap();
      toast.success("✅ Parent registered successfully!");
      setForm({
        fullName: "", mobile: "", email: "", address: "", password: "", studentIds: []
      });
    } catch (err) {
      toast.error(err.message || "❌ Failed to register parent");
    }
  };

  return (
    <Container className="my-4">
      <Card className="p-4 shadow border-0">
        <h4 className="mb-3 text-center">👨‍👩‍👧 Parent Registration</h4>
        <Form onSubmit={handleSubmit}>
          <Row>
            <Col md={6}>
              <Form.Group><Form.Label>Full Name *</Form.Label>
                <Form.Control name="fullName" value={form.fullName} onChange={handleChange} required />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group><Form.Label>Mobile *</Form.Label>
                <Form.Control name="mobile" value={form.mobile} onChange={handleChange} maxLength={10} required />
              </Form.Group>
            </Col>
          </Row>

          <Row className="mt-3">
            <Col md={6}>
              <Form.Group><Form.Label>Email</Form.Label>
                <Form.Control name="email" value={form.email} onChange={handleChange} type="email" />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group><Form.Label>Password *</Form.Label>
                <Form.Control type="password" name="password" value={form.password} onChange={handleChange} required />
              </Form.Group>
            </Col>
          </Row>

          <Row className="mt-3">
            <Col md={12}>
              <Form.Group><Form.Label>Address</Form.Label>
                <Form.Control as="textarea" rows={2} name="address" value={form.address} onChange={handleChange} />
              </Form.Group>
            </Col>
          </Row>

          <hr className="my-4" />
          <h5 className="text-primary">🎓 Link Students</h5>

          <Row className="mt-2">
            <Col md={12}>
              <Form.Group><Form.Label>Select Students (searchable)</Form.Label>
                <Select
                  isMulti
                  options={groupedStudentOptions}
                  onChange={handleStudentSelect}
                  placeholder="Search and select student(s)..."
                />
              </Form.Group>
            </Col>
          </Row>

          <div className="text-center mt-4">
            <Button type="submit" variant="success">Register Parent</Button>
          </div>
        </Form>
      </Card>
    </Container>
  );
};

export default AddParent;
