// src/pages/admin/AdminLayout.jsx
import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import AdminSidebar from '../../components/AdminSidebar';
import AdminHeader from '../../components/AdminHeader';
import './AdminLayout.css'; // style sidebar fixed and responsive

const AdminLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="admin-layout">
      <AdminHeader onToggle={() => setSidebarOpen(!sidebarOpen)} />

      <div className="d-flex">
        <div className={`admin-sidebar ${sidebarOpen ? 'show-sidebar' : 'hide-sidebar'}`}>

          <AdminSidebar />
        </div>

        <div className="admin-content flex-grow-1 p-3">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
